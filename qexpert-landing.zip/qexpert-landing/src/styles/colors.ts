const colors = {
    white: "#FFFFFF",
    green: "#00A984",
    foreground: "#F6F6F6",
    black: "#3D3D3D"
}

export default colors